﻿namespace API_1.Models
{
    public class Assets
    {
        public string AssetName     { get; set; }
        public string TypeOfAsset { get; set; }
        public double MonetaryValue { get; set; }
        public string OtherDetails { get; set; }

    }
}
