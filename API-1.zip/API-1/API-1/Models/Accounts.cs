﻿namespace API_1.Models
{
    public class Accounts
    {
        public string AccountNumber { get; set; }
        public string AccountType { get; set; }
        public double Balance { get; set; }
        public string StatusOfAccount { get; set; }

    }
}
