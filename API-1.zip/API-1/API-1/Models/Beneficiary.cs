﻿namespace API_1.Models
{
    public class Beneficiary
    {
        public string BeneficiaryType { get; set; }
        public string RelationshipWithAccountHolder { get; set; }
        public string DesignatedBeneficiaryName { get; set; }
        public string BeneficiaryAge { get; set; }
        public string BeneficiaryIdType { get; set; }
        public string BeneficiaryIdNumber  { get; set; }
        public string BeneficiaryUpdatedDate { get; set; }
        public string IsBeneficiaryMinor { get; set; }
        public string GaurdianDetails  { get; set; }
        public double percentage { get; set; }
        public double BeneficiaryAmount { get; set; }

    }
}
