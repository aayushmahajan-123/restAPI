﻿namespace API_1.Models
{
    public class UserAssetDetails
    {
        public string ECN { get; set; }
        public string CustomerName { get; set; }
        public int CustomerAge { get; set; }
        public string Address { get; set; }
        public List<Accounts> AccountDetails    { get; set; }   
        public List<Assets> AssetDetails { get; set; }
        public List<Beneficiary> BenificiaryDetails { get; set; }

    }
}
