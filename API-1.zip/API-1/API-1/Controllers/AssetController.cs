﻿using API_1.Data;
using API_1.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace API_1.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AssetController : ControllerBase
    {
        private IAssetData _assetData;
        public AssetController(IAssetData assetData)
        {
            _assetData = assetData;
        }
        [HttpGet]
        [Route("/api/v1/manage/accounts/{ECN}")]
        public IActionResult Get1(string ECN)
        {
            try
            {
                List<Accounts> l = _assetData.GetAccounts(ECN);
                return Ok(l);
            }
            catch(Exception e)
            {
                return BadRequest(e.Message);
            }
        }
        [HttpPut]
        [Route("/api/v1/manage/accounts/{ECN}")]
        public IActionResult Add1(string ECN, [FromBody] Accounts Ac)
        {
            try
            {
                _assetData.AddAccount(ECN,Ac);
                return Ok("Added Account");
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }
        [HttpPost]
        [Route("/api/v1/manage/accounts/{ECN}")]
        public IActionResult Update1(string ECN, [FromBody] Accounts Ac)
        {
            try
            {
                _assetData.UpdateAccountType(ECN, Ac);
                return Ok("Added Account");
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }

        [HttpGet]
        [Route("/api/v1/manage/assets/{ECN}")]
        public IActionResult Get2(string ECN)
        {
            try
            {
                List<Assets> l = _assetData.GetAssets(ECN);
                return Ok(l);
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }
        [HttpPut]
        [Route("/api/v1/manage/assets/{ECN}")]
        public IActionResult Add2(string ECN, [FromBody] Assets Asset)
        {
            try
            {
                _assetData.AddAsset(ECN, Asset);
                return Ok("Added Account");
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }
        [HttpGet]
        [Route("/api/v1/manage/beneficiary/{ECN}")]
        public IActionResult Get3(string ECN)
        {
            try
            {
                List<Beneficiary> l = _assetData.GetBeneficiaries(ECN);
                return Ok(l);
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }
        [HttpPut]
        [Route("/api/v1/manage/beneficiary/{ECN}")]
        public IActionResult Add3(string ECN, [FromBody] Beneficiary b)
        {
            try
            {
                _assetData.AddBeneficiary(ECN,b );
                return Ok("Added Account");
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }
        [HttpPost]
        [Route("/api/v1/manage/beneficiary/{ECN}")]
        public IActionResult Update2(string ECN, [FromBody] Beneficiary b)
        {
            try
            {
                _assetData.UpdateBeneficiary(ECN, b);
                return Ok("Added Account");
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }
    }
}
