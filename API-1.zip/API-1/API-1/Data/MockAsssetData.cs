﻿using API_1.Models;

namespace API_1.Data
{
    public class MockAsssetData : IAssetData
    {
        private List<UserAssetDetails> _users = new List<UserAssetDetails>()
        {
            new UserAssetDetails()
            {
                ECN = "8339787416572831",
                CustomerName = "Sierra Parks",
                CustomerAge = 28,
                Address = "68184 Joshua Wall Apt. 760\nPatriciamouth, MN 35184",
                AccountDetails = new List<Accounts>()
                {
                    new Accounts()
                    {
                        AccountNumber = "22398356379",
                        AccountType = "Individual Retirement Account",
                        Balance = 4998.04,
                        StatusOfAccount = "Active"
                    },
                    new Accounts()
                    {
                        AccountNumber = "23328456195",
                        AccountType = "Money market account",
                        Balance =  9557.18,
                        StatusOfAccount = "Active"
                    },
                    new Accounts()
                    {
                        AccountNumber = "73319213146",
                        AccountType = "Money market account",
                        Balance =  9456.95,
                        StatusOfAccount = "Active"
                    },
                     new Accounts()
                    {
                        AccountNumber = "39256891825",
                        AccountType = "Money market account",
                        Balance =  8402.6,
                        StatusOfAccount = "Active"
                    },
                     new Accounts()
                    {
                        AccountNumber = "42095690312",
                        AccountType = "Individual Retirement Account",
                        Balance =  1850.12,
                        StatusOfAccount = "Active"
                    }
                },
                AssetDetails = new List<Assets>()
                {
                    new Assets()
                    {
                        AssetName =  "Car at Texas",
                        TypeOfAsset = "Vehicles",
                        MonetaryValue = 3927.74,
                        OtherDetails =  "Individual",
                    },
                    new Assets()
                    {
                        AssetName =  "Artwork - 3",
                        TypeOfAsset = "Artwork",
                        MonetaryValue = 7879.66,
                        OtherDetails = "",
                    },
                    new Assets()
                    {
                        AssetName = "Car at Texas",
                        TypeOfAsset = "Vehicles",
                        MonetaryValue =  5186.59,
                        OtherDetails = "Individual" ,
                    },
                    new Assets()
                    {
                        AssetName =  "Plot at Texas",
                        TypeOfAsset = "Real Estate",
                        MonetaryValue = 9385.16,
                        OtherDetails = "",
                    },
                    new Assets()
                    {
                        AssetName =  "Home at Texas",
                        TypeOfAsset = "Home",
                        MonetaryValue = 9447.63,
                        OtherDetails = "Shared",
                    }
                },
                BenificiaryDetails = new List<Beneficiary>()
                {
                    new Beneficiary()
                    {
                        BeneficiaryType = "Individual",
                        RelationshipWithAccountHolder = "Son",
                        DesignatedBeneficiaryName = "Jeremy Hudson",
                        BeneficiaryAge = "13",
                        BeneficiaryIdType = "SSN",
                        BeneficiaryIdNumber = "2491771189679506",
                        BeneficiaryUpdatedDate = "2014-10-06",
                        IsBeneficiaryMinor = "Yes",
                        GaurdianDetails = "Robert English, 22058 Jasmine Springs\nCaseymouth, OK 54035",
                        percentage = 68611.574,
                        BeneficiaryAmount = 20
                    },
                    new Beneficiary()
                    {
                        BeneficiaryType = "Individual",
                        RelationshipWithAccountHolder = "Son",
                        DesignatedBeneficiaryName = "Sarah Wells",
                        BeneficiaryAge = "13",
                        BeneficiaryIdType = "SSN",
                        BeneficiaryIdNumber = "1919423574665313",
                        BeneficiaryUpdatedDate = "2016-01-21",
                        IsBeneficiaryMinor = "Yes",
                        GaurdianDetails =  "David Gonzales, 91338 Rosario Points\nGarciamouth, GA 49153",
                        percentage = 68611.574,
                        BeneficiaryAmount = 20
                    },
                    new Beneficiary()
                    {
                        BeneficiaryType ="Individual" ,
                        RelationshipWithAccountHolder = "Wife",
                        DesignatedBeneficiaryName ="Brenda Gardner" ,
                        BeneficiaryAge = "23",
                        BeneficiaryIdType = "SSN",
                        BeneficiaryIdNumber = "6685612004232421",
                        BeneficiaryUpdatedDate = "2021-04-27",
                        IsBeneficiaryMinor = "No",
                        GaurdianDetails ="" ,
                        percentage = 68611.574,
                        BeneficiaryAmount = 20
                    },
                    new Beneficiary()
                    {
                        BeneficiaryType =  "Institution",
                        RelationshipWithAccountHolder =  "Orphanage",
                        DesignatedBeneficiaryName = "Honey Drop Orphan Home" ,
                        BeneficiaryAge = "NA",
                        BeneficiaryIdType ="EIN" ,
                        BeneficiaryIdNumber = "2658541780847042",
                        BeneficiaryUpdatedDate ="2019-12-18" ,
                        IsBeneficiaryMinor = "NA",
                        GaurdianDetails = "",
                        percentage = 68611.574,
                        BeneficiaryAmount = 20
                    },
                    new Beneficiary()
                    {
                        BeneficiaryType = "Institution",
                        RelationshipWithAccountHolder = "Orphanage",
                        DesignatedBeneficiaryName = "Cradle of Love Home",
                        BeneficiaryAge = "NA",
                        BeneficiaryIdType = "EIN",
                        BeneficiaryIdNumber = "2590143202486996",
                        BeneficiaryUpdatedDate = "2020-06-22",
                        IsBeneficiaryMinor = "NA",
                        GaurdianDetails = "",
                        percentage = 68611.574,
                        BeneficiaryAmount = 20
                    }
                }
                
            }
        };
        public void AddAccount(string ECN,Accounts ac)
        {
            UserAssetDetails uad = _users.Single(x => x.ECN == ECN);
            uad.AccountDetails.Add(ac);
        }

        public void AddAsset(string ECN,Assets asset)
        {
            UserAssetDetails uad = _users.Single(x => x.ECN == ECN);
            uad.AssetDetails.Add(asset);
        }

        public void AddBeneficiary(string ECN,Beneficiary beneficiary)
        {
            UserAssetDetails uad = _users.Single(x => x.ECN == ECN);
            uad.BenificiaryDetails.Add(beneficiary);
        }

        public List<Accounts> GetAccounts(string ecn)
        {
            var x = _users.SingleOrDefault(x => x.ECN == ecn);
            return x.AccountDetails;

        }

        public List<Assets> GetAssets(string ECN)
        {
            var x = _users.SingleOrDefault(x => x.ECN == ECN);
            return x.AssetDetails;
        }

        public List<Beneficiary> GetBeneficiaries(string ECN)
        {
            var x = _users.SingleOrDefault(x => x.ECN == ECN);
            return x.BenificiaryDetails;

        }

        public void UpdateAccountType(string ECN,Accounts accounts)
        {
            UserAssetDetails uad = _users.Single(x => x.ECN == ECN);
            var oldaccount = uad.AccountDetails.Single(x => x.AccountNumber==accounts.AccountNumber);
            uad.AccountDetails.Remove(oldaccount);
            uad.AccountDetails.Add(accounts);
        }

        public void UpdateAsset(Assets asset)
        {
            throw new NotImplementedException();
        }

        public void UpdateBeneficiary(string ECN,Beneficiary beneficiary)
        {
             UserAssetDetails uad = _users.Single(x => x.ECN == ECN);
            var oldbene = uad.BenificiaryDetails.Single(x => x.BeneficiaryIdNumber==beneficiary.BeneficiaryIdNumber);
            uad.BenificiaryDetails.Remove(oldbene);
            uad.BenificiaryDetails.Add(beneficiary);
        }
    }
}
