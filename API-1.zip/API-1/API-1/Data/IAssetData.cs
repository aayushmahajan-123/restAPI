﻿using API_1.Models;

namespace API_1.Data
{
    public interface IAssetData
    {
        void AddAccount(string ECN,Accounts ac);
        void UpdateAccountType(string ECN,Accounts accounts);
        List<Accounts> GetAccounts(string ecn);
        void AddAsset(string ECN,Assets asset);
        void UpdateAsset(Assets asset);
        List<Assets> GetAssets(string ECN);
        void AddBeneficiary(string ECN,Beneficiary beneficiary);
        void UpdateBeneficiary(string ECN,Beneficiary beneficiary);
        List<Beneficiary> GetBeneficiaries(string ECN);
    }
}
